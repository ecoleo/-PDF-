/* ============================================================
   本地 PDF 核验台 · 应用逻辑
   PDF.js + Tesseract.js + IndexedDB · 全本地，无网络上传
   ============================================================ */

if (window.pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

// ---- IndexedDB helpers ----
const DB_NAME = 'pdf-verify-db';
const DB_VER = 1;
let db = null;
function openDB(){
  return new Promise((resolve,reject)=>{
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = (e)=>{
      const d = e.target.result;
      if(!d.objectStoreNames.contains('docs')) d.createObjectStore('docs',{keyPath:'id'});
      if(!d.objectStoreNames.contains('pages')) d.createObjectStore('pages',{keyPath:'id'});
      if(!d.objectStoreNames.contains('citations')) d.createObjectStore('citations',{keyPath:'id'});
    };
    req.onsuccess = ()=>resolve(req.result);
    req.onerror = ()=>reject(req.error);
  });
}
const tx = (s,m='readonly')=> db.transaction(s,m).objectStore(s);
const idbPut = (s,v)=> new Promise((r,j)=>{const q=tx(s,'readwrite').put(v);q.onsuccess=()=>r(q.result);q.onerror=()=>j(q.error);});
const idbAll = (s)=> new Promise((r,j)=>{const q=tx(s).getAll();q.onsuccess=()=>r(q.result||[]);q.onerror=()=>j(q.error);});
const idbDel = (s,k)=> new Promise((r,j)=>{const q=tx(s,'readwrite').delete(k);q.onsuccess=()=>r();q.onerror=()=>j(q.error);});
const idbClear = (s)=> new Promise((r,j)=>{const q=tx(s,'readwrite').clear();q.onsuccess=()=>r();q.onerror=()=>j(q.error);});

// ---- State ----
const state = {
  docs: [], pages: [], citations: [],
  currentView:'library', currentDoc:null, currentQuery:'',
  currentResults:[], currentHitIdx:0,
  searchMode:'phrase', searchScope:'all', typeFilter:'all',
  verifyOriginal:'', verifyOriginalMeta:null, verifyQuote:'',
  pdfDoc:null, pdfScale:1.2, ocrLang:'chi_sim+eng',
  renderedPages:new Map(),
};

// ---- Utils ----
const $ = (s,el=document)=>el.querySelector(s);
const $$ = (s,el=document)=>Array.from(el.querySelectorAll(s));
const fmtBytes = (n)=>{ n=n||0; if(n<1024) return n+' B'; if(n<1048576) return (n/1024).toFixed(1)+' KB'; if(n<1073741824) return (n/1048576).toFixed(1)+' MB'; return (n/1073741824).toFixed(2)+' GB'; };
const fmtDate = (t)=> new Date(t).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
const uid = ()=> 'id-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
const escapeHTML = (s)=> String(s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const escapeReg = (s)=> s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const debounce = (fn,ms)=>{ let t; return function(...a){ clearTimeout(t); t=setTimeout(()=>fn.apply(this,a),ms); }; };

function toast(msg,type='info',ms=2600){
  const el = document.createElement('div');
  el.className = 'toast '+type;
  el.textContent = msg;
  $('#toastWrap').appendChild(el);
  setTimeout(()=>{ el.style.transition='opacity .2s,transform .2s'; el.style.opacity='0'; el.style.transform='translateY(6px)'; setTimeout(()=>el.remove(),220); }, ms);
}

// ---- View switching ----
function switchView(name){
  state.currentView = name;
  $$('.view').forEach(v=>v.classList.toggle('active', v.id==='view-'+name));
  $$('#mainNav .nav-item').forEach(b=>b.classList.toggle('active', b.dataset.view===name));
  if(name==='library') renderLibrary();
  if(name==='search') renderSearch();
  if(name==='ocr') renderOCR();
  if(name==='storage') renderStorage();
  if(name==='verify') renderVerify();
}
$$('#mainNav .nav-item').forEach(b=> b.addEventListener('click', ()=> switchView(b.dataset.view)));

// ---- Type labels ----
const docTypeLabel = (t)=> ({text:'文字版',scanned:'扫描版',image:'图片版',mixed:'混合'}[t]||'未知');
const docStatusLabel = (s)=> ({queued:'排队中',processing:'解析中',ocr:'OCR中',indexed:'已索引',failed:'失败'}[s]||s);

// ---- Library render ----
function renderLibrary(){
  const grid = $('#docGrid'), empty = $('#libraryEmpty');
  const docs = state.docs.filter(d=> state.typeFilter==='all' || d.type===state.typeFilter);
  $('#docCountLabel').textContent = docs.length+' 份';
  $('#navDocCount').textContent = state.docs.length;
  $('#cntAll').textContent = state.docs.length;
  $('#cntText').textContent = state.docs.filter(d=>d.type==='text').length;
  $('#cntScanned').textContent = state.docs.filter(d=>d.type==='scanned').length;
  $('#cntImage').textContent = state.docs.filter(d=>d.type==='image').length;
  const totalPages = state.docs.reduce((a,d)=>a+(d.pages||0),0);
  const totalChars = state.pages.reduce((a,p)=>a+(p.text?p.text.length:0),0);
  $('#librarySub').textContent = `共 ${state.docs.length} 份文档 · ${totalPages} 页 · ${totalChars.toLocaleString('zh-CN')} 字`;

  if(docs.length===0){ grid.innerHTML=''; empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  grid.innerHTML = docs.map(d=>`
    <div class="doc-card ${state.currentDoc&&state.currentDoc.id===d.id?'active':''}" data-id="${d.id}" tabindex="0" role="button" aria-label="打开 ${escapeHTML(d.name)}">
      <div class="doc-thumb">
        ${d.thumb?`<img src="${d.thumb}" alt=""/>`:`<div class="doc-thumb-placeholder"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M6 2h8l4 4v16H6z"/><path d="M14 2v4h4"/></svg><span>无预览</span></div>`}
        <span class="doc-type-tag" data-type="${d.type}">${docTypeLabel(d.type)}</span>
        <span class="doc-status" data-status="${d.status}" title="${docStatusLabel(d.status)}"></span>
      </div>
      <div class="doc-info">
        <div class="doc-name" title="${escapeHTML(d.name)}">${escapeHTML(d.name)}</div>
        <div class="doc-meta"><span>${d.pages||0} 页</span><span class="doc-meta-dot"></span><span>${fmtBytes(d.size)}</span><span class="doc-meta-dot"></span><span>${fmtDate(d.addedAt)}</span></div>
        ${(d.status==='ocr'||d.status==='processing')?`<div class="doc-progress"><div class="doc-progress-fill" style="width:${d.progress||0}%"></div></div><div class="doc-meta" style="font-size:10.5px;color:var(--warning)">${docStatusLabel(d.status)} · ${Math.round(d.progress||0)}%</div>`:''}
        ${d.status==='failed'?`<div class="doc-meta" style="font-size:10.5px;color:var(--danger)">${escapeHTML(d.error||'解析失败')}</div>`:''}
        ${d.status==='indexed'?`<div class="doc-meta" style="font-size:10.5px;color:var(--success)">已索引 · ${(d.charCount||0).toLocaleString('zh-CN')} 字${d.confidence?` · 置信度 ${Math.round(d.confidence)}%`:''}</div>`:''}
      </div>
    </div>`).join('');
  $$('.doc-card',grid).forEach(card=>{
    card.addEventListener('click', ()=> openDoc(card.dataset.id));
    card.addEventListener('keydown', e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); openDoc(card.dataset.id);} });
  });
}

$$('#typeFilters .filter-chip').forEach(c=>{
  c.addEventListener('click', ()=>{
    $$('#typeFilters .filter-chip').forEach(x=>x.classList.remove('active'));
    c.classList.add('active');
    state.typeFilter = c.dataset.type;
    renderLibrary();
  });
});

// ---- Upload ----
$('#dropzone').addEventListener('click', ()=> $('#fileInput').click());
$('#dropzone').addEventListener('keydown', e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); $('#fileInput').click(); }});
$('#btnBrowse').addEventListener('click', e=>{ e.stopPropagation(); $('#fileInput').click(); });
$('#btnUploadTop').addEventListener('click', ()=> $('#fileInput').click());
$('#btnUploadSide').addEventListener('click', ()=> $('#fileInput').click());
$('#qaUpload').addEventListener('click', ()=> $('#fileInput').click());
['dragenter','dragover'].forEach(ev=> $('#dropzone').addEventListener(ev, e=>{ e.preventDefault(); e.stopPropagation(); $('#dropzone').classList.add('dragover'); }));
['dragleave','drop'].forEach(ev=> $('#dropzone').addEventListener(ev, e=>{ e.preventDefault(); e.stopPropagation(); $('#dropzone').classList.remove('dragover'); }));
$('#dropzone').addEventListener('drop', e=>{
  const files = Array.from(e.dataTransfer.files||[]).filter(f=> /\.pdf$/i.test(f.name) || f.type==='application/pdf');
  if(!files.length){ toast('请拖入 PDF 文件','warn'); return; }
  handleFiles(files);
});
$('#fileInput').addEventListener('change', e=>{
  const files = Array.from(e.target.files||[]);
  if(files.length) handleFiles(files);
  e.target.value='';
});

async function handleFiles(files){
  toast(`已加入 ${files.length} 个文件到处理队列`,'info');
  for(const f of files){
    if(f.size > 200*1024*1024){ toast(`${f.name} 超过 200 MB，已跳过`,'warn'); continue; }
    const buf = await f.arrayBuffer();
    const doc = {
      id: uid(), name: f.name, size: f.size, type:'text',
      status:'processing', progress:0, addedAt: Date.now(),
      ocrLang: state.ocrLang, pages:0, charCount:0, confidence:null,
      blob: buf,
    };
    await idbPut('docs', doc);
    state.docs.unshift(doc);
    renderLibrary(); updateStatusBar();
    processDoc(doc);
  }
}

async function processDoc(doc){
  try{
    const pdf = await pdfjsLib.getDocument({data: doc.blob.slice(0)}).promise;
    doc.pages = pdf.numPages;

    // 探测是否有文本层
    let sampleText = '';
    for(let i=1;i<=Math.min(3,pdf.numPages);i++){
      const p = await pdf.getPage(i);
      const tc = await p.getTextContent();
      sampleText += tc.items.map(it=>it.str).join(' ');
    }
    const hasText = sampleText.replace(/\s/g,'').length > 40;
    doc.type = hasText ? 'text' : 'scanned';
    doc.status = hasText ? 'processing' : 'ocr';
    doc.progress = 0;
    await idbPut('docs', doc);
    renderLibrary(); renderOCR();

    // 生成缩略图
    try{
      const p1 = await pdf.getPage(1);
      const vp1 = p1.getViewport({scale:0.4});
      const c = document.createElement('canvas');
      c.width=vp1.width; c.height=vp1.height;
      await p1.render({canvasContext:c.getContext('2d'),viewport:vp1}).promise;
      doc.thumb = c.toDataURL('image/jpeg',0.72);
      await idbPut('docs', doc); renderLibrary();
    }catch(e){ console.warn('thumb fail',e); }

    let totalChars = 0, confSum = 0, confCnt = 0;
    for(let pn=1; pn<=pdf.numPages; pn++){
      const page = await pdf.getPage(pn);
      let text='', words=[];
      if(hasText){
        const tc = await page.getTextContent();
        const vp = page.getViewport({scale:1});
        text = tc.items.map(it=>it.str).join(' ');
        words = tc.items.map(it=>{
          const tr = pdfjsLib.Util.transform(vp.transform, it.transform);
          const w = Math.abs(it.width * vp.scale) || 8;
          const h = Math.abs(it.height * vp.scale) || 10;
          return { t: it.str, x: tr[4], y: tr[5]-h, w, h };
        }).filter(w=> w.t && w.t.trim());
      } else {
        const vp = page.getViewport({scale:2});
        const c = document.createElement('canvas');
        c.width=vp.width; c.height=vp.height;
        await page.render({canvasContext:c.getContext('2d'),viewport:vp}).promise;
        const dataUrl = c.toDataURL('image/png');
        const ocrRes = await runOCR(dataUrl, doc.ocrLang, (p)=>{
          doc.progress = ((pn-1)+p/100)/pdf.numPages*100;
          idbPut('docs',doc); renderLibrary(); renderOCR();
        });
        text = ocrRes.text;
        words = (ocrRes.words||[]).map(w=>({
          t: w.text, x: w.bbox.x0/2, y: w.bbox.y0/2,
          w: (w.bbox.x1-w.bbox.x0)/2, h: (w.bbox.y1-w.bbox.y0)/2,
          conf: w.confidence,
        })).filter(w=> w.t && w.t.trim());
        if(ocrRes.confidence){ confSum += ocrRes.confidence; confCnt++; }
      }
      totalChars += text.length;
      const pageRec = { id: doc.id+'-p'+pn, docId: doc.id, pageNo: pn, text, words, source: hasText?'textlayer':'ocr' };
      await idbPut('pages', pageRec);
      state.pages.push(pageRec);
      doc.progress = pn/pdf.numPages*100;
      await idbPut('docs', doc);
      renderLibrary(); renderOCR(); updateStatusBar();
    }

    doc.status='indexed'; doc.progress=100; doc.charCount=totalChars;
    if(confCnt) doc.confidence = confSum/confCnt;
    await idbPut('docs', doc);
    renderLibrary(); renderOCR(); updateStatusBar();
    toast(`${doc.name} 解析完成 · ${pdf.numPages} 页 · ${totalChars.toLocaleString('zh-CN')} 字`,'success');
  } catch(err){
    console.error(err);
    doc.status='failed';
    doc.error = (err && err.message) ? err.message : '解析失败';
    await idbPut('docs', doc);
    renderLibrary(); renderOCR();
    toast(`${doc.name} 解析失败：${doc.error}`,'error',4200);
  }
}

// ---- OCR ----
let ocrWorker = null, ocrWorkerLang = null;
async function getOCRWorker(lang){
  if(ocrWorker && ocrWorkerLang===lang) return ocrWorker;
  if(ocrWorker){ try{ await ocrWorker.terminate(); }catch(e){} }
  setEngineStatus('加载语言包…','warn');
  ocrWorker = await Tesseract.createWorker(lang, 1, {
    logger: m=>{
      if(m.status==='loading language traineddata'){
        setEngineStatus(`加载语言包 ${Math.round((m.progress||0)*100)}%`,'warn');
      } else if(m.status && m.status!=='recognizing text'){
        setEngineStatus(m.status,'warn');
      }
    }
  });
  ocrWorkerLang = lang;
  setEngineStatus('就绪 · '+lang,'ok');
  return ocrWorker;
}
async function runOCR(imageDataUrl, lang, onProgress){
  const w = await getOCRWorker(lang);
  if(onProgress) onProgress(8);
  const { data } = await w.recognize(imageDataUrl);
  if(onProgress) onProgress(100);
  return {
    text: data.text||'',
    words: (data.words||[]).map(wd=>({ text: wd.text, bbox: wd.bbox, confidence: wd.confidence })),
    confidence: data.confidence||0,
  };
}
function setEngineStatus(text,kind){
  $('#engineStatus').textContent = text;
  $('#engineLang').textContent = state.ocrLang;
  $('#engineDot').className = 'status-dot '+(kind==='ok'?'ok':kind==='warn'?'warn':kind==='err'?'err':'');
  $('#statusEngine').textContent = text;
  $('#statusEngineDot').className = 'status-dot '+(kind==='ok'?'ok':kind==='warn'?'warn':kind==='err'?'err':'');
}
$('#ocrLangSelect').addEventListener('change', e=>{ state.ocrLang = e.target.value; setEngineStatus('就绪 · '+state.ocrLang,'ok'); toast('OCR 语言已切换为 '+state.ocrLang,'info'); });

// ---- Search ----
const normalize = (s)=> String(s||'').toLowerCase().replace(/\s+/g,' ').trim();
function tokenize(s){
  const norm = normalize(s), out = [];
  const en = norm.match(/[a-z0-9]+/g)||[];
  out.push(...en);
  const cjk = norm.replace(/[a-z0-9\s]/g,'');
  for(let i=0;i<cjk.length;i++){
    out.push(cjk[i]);
    if(i<cjk.length-1) out.push(cjk[i]+cjk[i+1]);
  }
  return out;
}

function searchDocs(query, mode, scope){
  const q = normalize(query);
  if(!q) return [];
  const docsInScope = state.docs.filter(d=>{
    if(d.status!=='indexed') return false;
    if(scope==='text') return d.type==='text';
    if(scope==='scanned') return d.type==='scanned'||d.type==='image';
    return true;
  });
  let re;
  try{
    if(mode==='regex') re = new RegExp(query,'gi');
    else if(mode==='phrase') re = new RegExp(escapeReg(q),'gi');
    else {
      const toks=[...new Set(tokenize(q))].filter(Boolean);
      if(!toks.length) return [];
      re = new RegExp(toks.map(escapeReg).join('|'),'gi');
    }
  }catch(e){ toast('正则无效','error'); return []; }

  const results = [];
  for(const doc of docsInScope){
    const pages = state.pages.filter(p=>p.docId===doc.id);
    for(const pg of pages){
      const text = pg.text||'';
      if(!text) continue;
      re.lastIndex = 0;
      let m, guard = 0;
      while((m = re.exec(text))!==null && guard++<80){
        if(m[0].length===0){ re.lastIndex++; continue; }
        const idx = m.index, len = m[0].length;
        const ctxStart = Math.max(0, idx-60), ctxEnd = Math.min(text.length, idx+len+60);
        // Locate bbox from words
        let bbox = null;
        if(pg.words && pg.words.length){
          let cum = 0;
          for(let wi=0; wi<pg.words.length; wi++){
            const w = pg.words[wi];
            const wEnd = cum + w.t.length;
            if(wEnd > idx && cum < idx+len){
              const b = { x:w.x, y:w.y, w:w.w, h:w.h };
              if(!bbox) bbox = b;
              else bbox = {
                x: Math.min(bbox.x, b.x),
                y: Math.min(bbox.y, b.y),
                w: Math.max(bbox.x+bbox.w, b.x+b.w) - Math.min(bbox.x, b.x),
                h: Math.max(bbox.y+bbox.h, b.y+b.h) - Math.min(bbox.y, b.y),
              };
            }
            cum = wEnd + 1;
            if(cum >= idx+len) break;
          }
        }
        results.push({
          id: uid(), docId: doc.id, docName: doc.name, docType: doc.type,
          pageNo: pg.pageNo, match: m[0],
          before: text.slice(ctxStart, idx),
          after: text.slice(idx+len, ctxEnd),
          idx, len, bbox,
          confidence: doc.confidence!=null ? doc.confidence : (pg.source==='textlayer'?99:null),
          source: pg.source,
        });
      }
    }
  }
  results.sort((a,b)=> (b.confidence||0)-(a.confidence||0));
  return results;
}

function highlightSnippet(text, query, mode){
  const esc = escapeHTML(text);
  if(!query) return esc;
  let re;
  try{
    if(mode==='regex') re = new RegExp(query,'gi');
    else if(mode==='phrase') re = new RegExp(escapeReg(query),'gi');
    else {
      const toks=[...new Set(tokenize(query))].filter(Boolean);
      re = new RegExp(toks.map(escapeReg).join('|'),'gi');
    }
  }catch(e){ return esc; }
  return esc.replace(re, m=> `<mark>${m}</mark>`);
}

function renderSearch(){
  const list = $('#resultsList'), q = state.currentQuery;
  $('#navHitCount').textContent = state.currentResults.length;
  if(!q){
    $('#searchSummaryText').innerHTML = '输入关键词开始检索。支持精确短语、分词模糊、正则三种模式。';
    list.innerHTML = `<div class="empty-state">
      <svg class="empty-illo" viewBox="0 0 120 96" fill="none">
        <circle cx="52" cy="44" r="26" fill="var(--illus-bg)" stroke="var(--illus-stroke)" stroke-width="1.5"/>
        <path d="M70 62l20 20" stroke="var(--primary)" stroke-width="4" stroke-linecap="round"/>
        <path d="M40 44h24M40 36h24M40 52h16" stroke="var(--illus-line)" stroke-width="2" stroke-linecap="round"/>
      </svg>
      <div class="empty-title">开始你的第一次检索</div>
      <div class="empty-desc">在顶部搜索框输入关键词或整句，系统会在本地索引中查找，并展示命中位置、上下文与 OCR 置信度。</div>
    </div>`;
    return;
  }
  const rs = state.currentResults;
  const modeLabel = {phrase:'精确短语',fuzzy:'分词模糊',regex:'正则'}[state.searchMode];
  $('#searchSummaryText').innerHTML = rs.length>0
    ? `在 <strong>${new Set(rs.map(r=>r.docId)).size}</strong> 份文档中找到 <strong>${rs.length}</strong> 处命中 · 查询 <span class="q">${escapeHTML(q)}</span> · 模式：${modeLabel}`
    : `未找到 <span class="q">${escapeHTML(q)}</span> 的命中。可尝试切换为「分词模糊」或缩短查询。`;

  if(!rs.length){
    list.innerHTML = `<div class="empty-state">
      <svg class="empty-illo" viewBox="0 0 120 96" fill="none">
        <circle cx="52" cy="44" r="26" fill="var(--danger-soft)" stroke="var(--border-danger)" stroke-width="1.5"/>
        <path d="M42 34l20 20M62 34L42 54" stroke="var(--danger)" stroke-width="3" stroke-linecap="round"/>
        <path d="M70 62l20 20" stroke="var(--illus-muted)" stroke-width="4" stroke-linecap="round"/>
      </svg>
      <div class="empty-title">没有找到匹配内容</div>
      <div class="empty-desc">建议：① 切换为「分词模糊」模式；② 缩短查询词；③ 检查文档是否已完成索引（在 OCR 队列中查看）。</div>
    </div>`;
    return;
  }

  list.innerHTML = rs.slice(0,200).map((r,i)=>`
    <div class="result-card ${i===state.currentHitIdx?'active':''}" data-i="${i}">
      <div class="result-head">
        <div class="result-doc">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 2h6l3 3v9H4z"/><path d="M10 2v3h3"/></svg>
          <span class="result-doc-name" title="${escapeHTML(r.docName)}">${escapeHTML(r.docName)}</span>
        </div>
        <span class="result-page">第 ${r.pageNo} 页</span>
        <span class="result-tag">${docTypeLabel(r.docType)}</span>
        <span class="result-tag">${r.source==='ocr'?'OCR':'文本层'}</span>
        <div class="result-score">
          ${r.confidence!=null?`<span>置信度</span>
            <div class="confidence-bar"><div class="confidence-fill" style="width:${Math.min(100,r.confidence)}%;background:${r.confidence>=85?'var(--success)':r.confidence>=60?'var(--warning)':'var(--danger)'}"></div></div>
            <strong style="color:var(--fg);font-variant-numeric:tabular-nums">${Math.round(r.confidence)}%</strong>`:'<span>无置信度</span>'}
        </div>
      </div>
      <div class="result-snippet">${highlightSnippet(r.before + r.match + r.after, q, state.searchMode)}</div>
      <div class="result-context">位置：字符 ${r.idx}–${r.idx+r.len} · 命中 ${r.len} 字${r.bbox?'':' · 无精确坐标（将按页面定位）'}</div>
      <div class="result-actions">
        <button class="btn btn-sm primary" data-act="jump">
          <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 8h10M9 4l4 4-4 4"/></svg>跳转并高亮
        </button>
        <button class="btn btn-sm" data-act="verify">
          <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2"><path d="M2.5 8.5l3 3 8-8"/></svg>加入核验
        </button>
        <button class="btn btn-sm ghost" data-act="copy">复制片段</button>
      </div>
    </div>`).join('');

  $$('.result-card',list).forEach(card=>{
    const i = +card.dataset.i, r = rs[i];
    card.addEventListener('click', e=>{
      const btn = e.target.closest('[data-act]');
      const act = btn ? btn.dataset.act : 'jump';
      if(act==='verify'){ addToVerify(r); return; }
      if(act==='copy'){
        navigator.clipboard.writeText(r.before+r.match+r.after).then(()=> toast('已复制片段','success'));
        return;
      }
      state.currentHitIdx = i;
      jumpToHit(r);
    });
  });
}

$('#globalSearch').addEventListener('input', debounce(e=>{
  state.currentQuery = e.target.value.trim();
  if(state.currentQuery){
    state.currentResults = searchDocs(state.currentQuery, state.searchMode, state.searchScope);
    state.currentHitIdx = 0;
    if(state.currentView!=='search') switchView('search'); else renderSearch();
  } else { state.currentResults=[]; renderSearch(); }
},260));
$('#globalSearch').addEventListener('keydown', e=>{
  if(e.key==='Enter'){
    state.currentQuery = e.target.value.trim();
    state.currentResults = searchDocs(state.currentQuery, state.searchMode, state.searchScope);
    state.currentHitIdx = 0;
    switchView('search');
  }
});
document.addEventListener('keydown', e=>{
  if((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==='k'){ e.preventDefault(); $('#globalSearch').focus(); $('#globalSearch').select(); }
});
$('#searchModeBtn').addEventListener('click', ()=>{
  const modes=['phrase','fuzzy','regex'], labels={phrase:'精确短语',fuzzy:'分词模糊',regex:'正则'};
  state.searchMode = modes[(modes.indexOf(state.searchMode)+1)%modes.length];
  $('#searchModeLabel').textContent = labels[state.searchMode];
  if(state.currentQuery){ state.currentResults = searchDocs(state.currentQuery,state.searchMode,state.searchScope); renderSearch(); }
});
$$('#searchFilters .chip').forEach(c=> c.addEventListener('click', ()=>{
  $$('#searchFilters .chip').forEach(x=>x.classList.remove('active'));
  c.classList.add('active');
  state.searchScope = c.dataset.scope;
  if(state.currentQuery){ state.currentResults = searchDocs(state.currentQuery,state.searchMode,state.searchScope); renderSearch(); }
}));
$('#btnClearSearch').addEventListener('click', ()=>{ $('#globalSearch').value=''; state.currentQuery=''; state.currentResults=[]; renderSearch(); });

// ---- Viewer ----
async function openDoc(docId, hit=null){
  const doc = state.docs.find(d=>d.id===docId);
  if(!doc) return;
  if(doc.status!=='indexed'){ toast('该文档尚未完成解析','warn'); return; }
  state.currentDoc = doc;
  $('#viewerDocName').textContent = doc.name;
  switchView('viewer');
  await renderPDF(doc, hit);
  renderRightPanel(doc, hit);
}
async function jumpToHit(r){
  const doc = state.docs.find(d=>d.id===r.docId);
  if(!doc) return;
  state.currentDoc = doc;
  $('#viewerDocName').textContent = doc.name;
  switchView('viewer');
  await renderPDF(doc, r);
  renderRightPanel(doc, r);
}

async function renderPDF(doc, hit){
  const scroll = $('#viewerScroll');
  scroll.innerHTML = '<div style="padding:40px;color:var(--muted);text-align:center"><div class="spinner" style="margin:0 auto 12px"></div><div style="font-size:12px">正在加载 PDF…</div></div>';
  try{
    const pdf = await pdfjsLib.getDocument({data: doc.blob.slice(0)}).promise;
    state.pdfDoc = pdf;
    $('#pageTotal').textContent = pdf.numPages;
    scroll.innerHTML = '';
    state.renderedPages.clear();

    const docHits = state.currentResults.filter(r=>r.docId===doc.id);
    const hitByPage = {};
    docHits.forEach(r=>{ (hitByPage[r.pageNo]=hitByPage[r.pageNo]||[]).push(r); });

    for(let pn=1; pn<=pdf.numPages; pn++){
      const page = await pdf.getPage(pn);
      const vp = page.getViewport({scale: state.pdfScale});
      const wrap = document.createElement('div');
      wrap.className='pdf-page-wrap';
      wrap.style.width = vp.width+'px'; wrap.style.height = vp.height+'px';
      wrap.dataset.page = pn;
      const canvas = document.createElement('canvas');
      canvas.width = vp.width; canvas.height = vp.height;
      wrap.appendChild(canvas);
      await page.render({canvasContext:canvas.getContext('2d'), viewport:vp}).promise;

      const overlay = document.createElement('div');
      overlay.className='hit-overlay';
      const pageHits = hitByPage[pn]||[];
      pageHits.forEach((r,i)=>{
        if(!r.bbox) return;
        const s = state.pdfScale;
        const box = document.createElement('div');
        box.className='hit-box';
        box.style.left = (r.bbox.x*s)+'px';
        box.style.top = (r.bbox.y*s)+'px';
        box.style.width = Math.max(4, r.bbox.w*s)+'px';
        box.style.height = Math.max(4, r.bbox.h*s)+'px';
        box.dataset.rid = r.id;
        box.title = `命中 ${i+1}/${pageHits.length}：${r.match}`;
        if(hit && hit.id===r.id) box.classList.add('current');
        box.addEventListener('click', ()=>{
          const idx = state.currentResults.findIndex(x=>x.id===r.id);
          if(idx>=0) state.currentHitIdx = idx;
          $$('.hit-box',scroll).forEach(b=>b.classList.remove('current'));
          box.classList.add('current');
          updateHitNav();
          renderRightPanel(doc, r);
        });
        overlay.appendChild(box);
      });
      wrap.appendChild(overlay);
      const label = document.createElement('div');
      label.className='page-label';
      label.textContent = `第 ${pn} 页 / 共 ${pdf.numPages} 页`;
      wrap.appendChild(label);
      scroll.appendChild(wrap);
      state.renderedPages.set(pn, {wrap, vp});
    }
    updateHitNav();
    if(hit){
      $('#pageInput').value = hit.pageNo;
      setTimeout(()=>{
        const box = scroll.querySelector(`.hit-box[data-rid="${hit.id}"]`);
        if(box) box.closest('.pdf-page-wrap').scrollIntoView({behavior:'smooth',block:'center'});
        else {
          const w = state.renderedPages.get(hit.pageNo);
          if(w) w.wrap.scrollIntoView({behavior:'smooth',block:'start'});
        }
      },100);
    } else {
      $('#pageInput').value = 1;
    }
    $('#zoomLabel').textContent = Math.round(state.pdfScale/1.2*100)+'%';
  } catch(err){
    console.error(err);
    scroll.innerHTML = `<div class="empty-state"><div class="empty-title">PDF 渲染失败</div><div class="empty-desc">${escapeHTML(err.message||'未知错误')}</div></div>`;
  }
}

function updateHitNav(){
  const docHits = state.currentResults.filter(r=> state.currentDoc && r.docId===state.currentDoc.id);
  if(!docHits.length){ $('#hitNavText').textContent='无命中'; return; }
  const cur = docHits[state.currentHitIdx] || docHits[0];
  const i = docHits.findIndex(r=>r.id===cur.id);
  $('#hitNavText').textContent = `第 ${i+1} / ${docHits.length} 处命中 · 第 ${cur.pageNo} 页`;
}

$('#btnViewerBack').addEventListener('click', ()=> switchView(state.currentQuery?'search':'library'));
$('#btnPrevPage').addEventListener('click', ()=>{ const v=Math.max(1,+$('#pageInput').value-1); gotoPage(v); });
$('#btnNextPage').addEventListener('click', ()=>{ const v=Math.min(+(state.pdfDoc?state.pdfDoc.numPages:1),+$('#pageInput').value+1); gotoPage(v); });
$('#pageInput').addEventListener('change', ()=> gotoPage(+$('#pageInput').value));
function gotoPage(p){
  const w = state.renderedPages.get(p);
  if(w){ w.wrap.scrollIntoView({behavior:'smooth',block:'start'}); $('#pageInput').value=p; }
}
$('#btnZoomIn').addEventListener('click', ()=>{ state.pdfScale=Math.min(3, state.pdfScale+0.2); if(state.currentDoc) renderPDF(state.currentDoc, state.currentResults[state.currentHitIdx]); });
$('#btnZoomOut').addEventListener('click', ()=>{ state.pdfScale=Math.max(0.5, state.pdfScale-0.2); if(state.currentDoc) renderPDF(state.currentDoc, state.currentResults[state.currentHitIdx]); });
$('#btnZoomFit').addEventListener('click', ()=>{ state.pdfScale=1.2; if(state.currentDoc) renderPDF(state.currentDoc, state.currentResults[state.currentHitIdx]); });
$('#btnPrevHit').addEventListener('click', ()=>{
  const docHits = state.currentResults.filter(r=> state.currentDoc && r.docId===state.currentDoc.id);
  if(!docHits.length) return;
  state.currentHitIdx = (state.currentHitIdx-1+docHits.length)%docHits.length;
  jumpToHit(docHits[state.currentHitIdx]);
});
$('#btnNextHit').addEventListener('click', ()=>{
  const docHits = state.currentResults.filter(r=> state.currentDoc && r.docId===state.currentDoc.id);
  if(!docHits.length) return;
  state.currentHitIdx = (state.currentHitIdx+1)%docHits.length;
  jumpToHit(docHits[state.currentHitIdx]);
});
$('#btnAddToVerify').addEventListener('click', ()=>{
  const r = state.currentResults[state.currentHitIdx];
  if(!r){ toast('请先在搜索结果中选择一处命中','warn'); return; }
  addToVerify(r);
});

// ---- Verify ----
function addToVerify(r){
  state.verifyOriginal = r.before + r.match + r.after;
  state.verifyOriginalMeta = { docId:r.docId, docName:r.docName, pageNo:r.pageNo, match:r.match, rid:r.id };
  state.verifyQuote = r.match;
  switchView('verify');
  renderVerify();
  toast('已加入核验，右侧可编辑引用文本','success');
}

function diffChars(a, b){
  // LCS-based char diff. a=original, b=quote
  const n=a.length, m=b.length;
  if(n*m > 400000){
    // fallback for very long strings
    return { ops:[{t:'=',v:a}], match:n, ins:0, del:0, sim: a===b?1:0 };
  }
  const dp = Array.from({length:n+1},()=> new Uint16Array(m+1));
  for(let i=n-1;i>=0;i--) for(let j=m-1;j>=0;j--){
    dp[i][j] = a[i]===b[j] ? dp[i+1][j+1]+1 : Math.max(dp[i+1][j], dp[i][j+1]);
  }
  const ops=[]; let i=0,j=0,match=0,ins=0,del=0;
  while(i<n && j<m){
    if(a[i]===b[j]){ ops.push({t:'=',v:a[i]}); i++;j++;match++; }
    else if(dp[i+1][j] >= dp[i][j+1]){ ops.push({t:'-',v:a[i]}); i++; del++; }
    else { ops.push({t:'+',v:b[j]}); j++; ins++; }
  }
  while(i<n){ ops.push({t:'-',v:a[i]}); i++; del++; }
  while(j<m){ ops.push({t:'+',v:b[j]}); j++; ins++; }
  // merge consecutive same-type ops
  const merged=[];
  for(const op of ops){
    const last = merged[merged.length-1];
    if(last && last.t===op.t) last.v += op.v;
    else merged.push({t:op.t, v:op.v});
  }
  const sim = (n+m) ? (2*match)/(n+m) : 1;
  return { ops: merged, match, ins, del, sim };
}

function renderVerify(){
  $('#navVerifyCount').textContent = state.citations.length;
  $('#citationsCount').textContent = state.citations.length+' 条';
  // Original panel
  const origEl = $('#verifyOriginal');
  if(state.verifyOriginal){
    const meta = state.verifyOriginalMeta;
    $('#originalMeta').textContent = meta ? `${meta.docName} · 第 ${meta.pageNo} 页` : '原文';
    const m = state.verifyOriginalMeta?.match || '';
    if(m && state.verifyOriginal.includes(m)){
      const idx = state.verifyOriginal.indexOf(m);
      origEl.innerHTML = escapeHTML(state.verifyOriginal.slice(0,idx)) +
        '<mark>' + escapeHTML(m) + '</mark>' +
        escapeHTML(state.verifyOriginal.slice(idx+m.length));
    } else {
      origEl.textContent = state.verifyOriginal;
    }
  } else {
    $('#originalMeta').textContent = '未选择';
    origEl.textContent = '在搜索结果中点击「加入核验」，或先在文档库选择一份文档、在查看器中选一段命中，系统会自动带上命中前后各 60 字作为上下文。';
  }
  $('#verifyQuote').value = state.verifyQuote || '';

  // Citations list
  const list = $('#citationsList');
  if(!state.citations.length){
    list.innerHTML = '<div style="padding:32px;text-align:center;color:var(--muted);font-size:12px">还没有核验记录。在搜索结果中点击「加入核验」开始第一次比对。</div>';
  } else {
    list.innerHTML = state.citations.slice().reverse().map(c=>`
      <div class="citation-row" data-id="${c.id}">
        <span class="citation-verdict" data-v="${c.verdict}"></span>
        <div class="citation-main">
          <div class="citation-quote">“${escapeHTML(c.quote.length>90?c.quote.slice(0,90)+'…':c.quote)}”</div>
          <div class="citation-meta">
            <span>${escapeHTML(c.docName||'')}</span>·<span>第 ${c.pageNo} 页</span>·<span>相似度 ${Math.round(c.sim*100)}%</span>·<span>${fmtDate(c.createdAt)}</span>
          </div>
        </div>
        <button class="btn btn-sm ghost" data-act="del">删除</button>
      </div>`).join('');
    $$('.citation-row',list).forEach(row=>{
      row.addEventListener('click', e=>{
        const id = row.dataset.id;
        if(e.target.closest('[data-act="del"]')){
          idbDel('citations', id);
          state.citations = state.citations.filter(c=>c.id!==id);
          renderVerify(); updateStatusBar(); toast('已删除记录','info'); return;
        }
        const c = state.citations.find(x=>x.id===id);
        if(c){ state.verifyOriginal = c.original; state.verifyQuote = c.quote; state.verifyOriginalMeta = {docId:c.docId,docName:c.docName,pageNo:c.pageNo,match:''}; renderVerify(); runVerify(false); }
      });
    });
  }
}

function runVerify(save=true){
  const orig = state.verifyOriginal || '';
  const quote = $('#verifyQuote').value || '';
  state.verifyQuote = quote;
  if(!orig.trim() || !quote.trim()){
    $('#verifyVerdict').dataset.verdict = 'idle';
    $('#verifyVerdictText').textContent = '等待核验';
    $('#statMatch').textContent='—'; $('#statDel').textContent='—'; $('#statIns').textContent='—'; $('#statSim').textContent='—';
    return;
  }
  const d = diffChars(orig, quote);
  // Render original with del highlights
  let origHTML='', quoteHTML='';
  for(const op of d.ops){
    const v = escapeHTML(op.v);
    if(op.t==='='){ origHTML += `<mark>${v}</mark>`; quoteHTML += `<mark>${v}</mark>`; }
    else if(op.t==='-'){ origHTML += `<span class="diff-del">${v}</span>`; }
    else { quoteHTML += `<span class="diff-ins">${v}</span>`; }
  }
  $('#verifyOriginal').innerHTML = origHTML;
  // Replace textarea with rendered preview overlay? Keep textarea but show quote diff below.
  // We render quote diff into a sibling overlay: simpler—put it into original panel's counterpart via a temporary div
  const qPanel = $('#verifyQuote').parentElement;
  let qPreview = qPanel.querySelector('.verify-content');
  if(!qPreview){
    qPreview = document.createElement('div');
    qPreview.className = 'verify-content';
    qPreview.style.borderTop = '1px dashed var(--border)';
    qPreview.style.minHeight = '80px';
    qPanel.appendChild(qPreview);
  }
  qPreview.innerHTML = '<div style="font-size:10.5px;color:var(--muted);margin-bottom:6px;letter-spacing:.04em;text-transform:uppercase;font-weight:600">逐字对照预览</div>' + quoteHTML;

  const sim = d.sim;
  const verdict = sim>=0.98 ? 'match' : sim>=0.6 ? 'partial' : 'mismatch';
  const verdictText = {match:'引用与原文一致',partial:'部分一致，存在差异',mismatch:'与原文不一致'}[verdict];
  $('#verifyVerdict').dataset.verdict = verdict;
  $('#verifyVerdictText').textContent = verdictText;
  $('#statMatch').textContent = d.match;
  $('#statDel').textContent = d.del;
  $('#statIns').textContent = d.ins;
  $('#statSim').textContent = Math.round(sim*100)+'%';

  if(save){
    const meta = state.verifyOriginalMeta || {};
    const rec = {
      id: uid(), docId: meta.docId||'', docName: meta.docName||'', pageNo: meta.pageNo||0,
      original: orig, quote, verdict, sim, match:d.match, ins:d.ins, del:d.del,
      createdAt: Date.now(),
    };
    idbPut('citations', rec);
    state.citations.push(rec);
    renderVerify(); updateStatusBar();
    toast(`核验完成：${verdictText}`,'success');
  }
}

$('#btnVerifyRun').addEventListener('click', ()=> runVerify(true));
$('#btnVerifyClear').addEventListener('click', ()=>{
  state.verifyOriginal=''; state.verifyQuote=''; state.verifyOriginalMeta=null;
  const qPanel = $('#verifyQuote').parentElement;
  const prev = qPanel.querySelector('.verify-content'); if(prev) prev.remove();
  $('#verifyVerdict').dataset.verdict='idle'; $('#verifyVerdictText').textContent='等待核验';
  $('#statMatch').textContent='—'; $('#statDel').textContent='—'; $('#statIns').textContent='—'; $('#statSim').textContent='—';
  renderVerify();
});
$('#btnVerifySwap').addEventListener('click', ()=>{
  const a = state.verifyOriginal, b = $('#verifyQuote').value;
  state.verifyOriginal = b; $('#verifyQuote').value = a; state.verifyQuote = a;
  runVerify(false);
});
$('#verifyQuote').addEventListener('input', debounce(()=> runVerify(false), 320));
$('#btnExportCitations').addEventListener('click', ()=>{
  const blob = new Blob([JSON.stringify(state.citations,null,2)],{type:'application/json'});
  downloadBlob(blob, `citations-${Date.now()}.json`);
});

// ---- Right panel ----
function renderRightPanel(doc, hit){
  const sel = $('#rightSelection');
  if(!doc){ sel.innerHTML = '<div style="padding:14px 12px;background:var(--surface-2);border:1px solid var(--border);border-radius:6px;font-size:12px;color:var(--muted);line-height:1.6;text-align:center">在文档库或搜索结果中选择一项，这里会显示元数据、命中详情与相关命中。</div>'; return; }
  $('#rightTitle').textContent = doc.name.length>24 ? doc.name.slice(0,24)+'…' : doc.name;
  const relatedHits = hit ? state.currentResults.filter(r=> r.docId===doc.id && r.id!==hit.id).slice(0,6) : [];
  sel.innerHTML = `
    <div class="kv-list" style="margin-bottom:14px">
      <div class="kv"><span class="kv-key">类型</span><span class="kv-val">${docTypeLabel(doc.type)}</span></div>
      <div class="kv"><span class="kv-key">页数</span><span class="kv-val">${doc.pages||0}</span></div>
      <div class="kv"><span class="kv-key">大小</span><span class="kv-val">${fmtBytes(doc.size)}</span></div>
      <div class="kv"><span class="kv-key">字数</span><span class="kv-val">${(doc.charCount||0).toLocaleString('zh-CN')}</span></div>
      <div class="kv"><span class="kv-key">状态</span><span class="kv-val">${docStatusLabel(doc.status)}</span></div>
      ${doc.confidence?`<div class="kv"><span class="kv-key">OCR置信度</span><span class="kv-val">${Math.round(doc.confidence)}%</span></div>`:''}
      <div class="kv"><span class="kv-key">上传于</span><span class="kv-val">${fmtDate(doc.addedAt)}</span></div>
      <div class="kv"><span class="kv-key">ID</span><span class="kv-val mono">${doc.id}</span></div>
    </div>
    ${hit?`
      <div class="right-section-title" style="margin-top:16px">当前命中</div>
      <div style="padding:10px 12px;background:var(--warning-soft);border:1px solid #FDE68A;border-radius:6px;font-size:12px;color:#78350F;line-height:1.6;margin-bottom:10px">
        <strong>第 ${hit.pageNo} 页</strong> · 字符 ${hit.idx}–${hit.idx+hit.len}<br/>
        <span style="font-family:var(--font-mono);font-size:11.5px">${escapeHTML(hit.match)}</span>
      </div>
    `:''}
    ${relatedHits.length?`
      <div class="right-section-title" style="margin-top:14px">同文档相关命中</div>
      ${relatedHits.map(r=>`
        <div class="related-hit" data-rid="${r.id}">
          ${escapeHTML((r.before.slice(-30)||''))}<mark>${escapeHTML(r.match)}</mark>${escapeHTML(r.after.slice(0,30)||'')}
          <div class="related-hit-meta">第 ${r.pageNo} 页 · ${r.source==='ocr'?'OCR':'文本层'}</div>
        </div>`).join('')}
    `:''}
    <div style="display:flex;gap:6px;margin-top:14px">
      <button class="btn btn-sm" id="rpOpen" style="flex:1">打开文档</button>
      <button class="btn btn-sm danger" id="rpDelete">删除</button>
    </div>
  `;
  $$('.related-hit',sel).forEach(el=> el.addEventListener('click', ()=>{
    const r = state.currentResults.find(x=>x.id===el.dataset.rid);
    if(r){ state.currentHitIdx = state.currentResults.indexOf(r); jumpToHit(r); }
  }));
  const rpOpen = $('#rpOpen',sel); if(rpOpen) rpOpen.addEventListener('click', ()=> openDoc(doc.id));
  const rpDel = $('#rpDelete',sel); if(rpDel) rpDel.addEventListener('click', async ()=>{
    if(!confirm(`确认从本地删除「${doc.name}」？此操作不可撤销。`)) return;
    await idbDel('docs', doc.id);
    const pages = state.pages.filter(p=>p.docId===doc.id);
    for(const p of pages) await idbDel('pages', p.id);
    state.pages = state.pages.filter(p=>p.docId!==doc.id);
    state.docs = state.docs.filter(d=>d.id!==doc.id);
    if(state.currentDoc && state.currentDoc.id===doc.id) state.currentDoc=null;
    renderLibrary(); renderOCR(); updateStatusBar(); switchView('library');
    toast('已从本地删除','info');
  });
}

$('#btnToggleRight').addEventListener('click', ()=>{
  const cur = $('#app').dataset.rightCollapsed==='true';
  $('#app').dataset.rightCollapsed = cur?'false':'true';
});
$('#btnCloseRight').addEventListener('click', ()=>{ $('#app').dataset.rightCollapsed='true'; });
$('#qaSample').addEventListener('click', ()=> loadSample());
$('#qaStorage').addEventListener('click', ()=> switchView('storage'));

// ---- OCR view ----
function renderOCR(){
  const jobs = state.docs.filter(d=> d.status==='ocr' || d.status==='processing' || d.status==='indexed' || d.status==='failed');
  const active = state.docs.filter(d=> d.status==='ocr'||d.status==='processing');
  const done = state.docs.filter(d=> d.status==='indexed');
  const failed = state.docs.filter(d=> d.status==='failed');
  const confs = done.map(d=>d.confidence).filter(Boolean);
  const avgConf = confs.length ? confs.reduce((a,b)=>a+b,0)/confs.length : null;

  $('#ocrStatActive').textContent = active.length;
  $('#ocrStatDone').textContent = done.length;
  $('#ocrStatFailed').textContent = failed.length;
  $('#ocrStatConf').textContent = avgConf!=null ? Math.round(avgConf)+'%' : '—';
  $('#navOcrCount').textContent = active.length;
  $('#ocrListCount').textContent = jobs.length+' 个任务';

  const wrap = $('#ocrJobs');
  if(!jobs.length){ wrap.innerHTML=''; $('#ocrEmpty').classList.remove('hidden'); return; }
  $('#ocrEmpty').classList.add('hidden');
  wrap.innerHTML = jobs.map(d=>`
    <div class="ocr-job" data-status="${d.status}">
      <div class="ocr-job-icon">
        ${d.status==='indexed'?'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M2.5 8.5l3 3 8-8"/></svg>':
          d.status==='failed'?'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4l8 8M12 4l-8 8"/></svg>':
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2" y="3" width="12" height="10" rx="1.5"/><path d="M5 7h6M5 10h4"/></svg>'}
      </div>
      <div class="ocr-job-main">
        <div class="ocr-job-head">
          <span class="ocr-job-name" title="${escapeHTML(d.name)}">${escapeHTML(d.name)}</span>
          <span class="ocr-job-status">${docStatusLabel(d.status)}</span>
          <span class="result-tag" style="margin-left:auto">${docTypeLabel(d.type)}</span>
        </div>
        <div class="ocr-progress"><div class="ocr-progress-fill" style="width:${d.progress||0}%"></div></div>
        <div class="ocr-job-meta">
          <span>${d.pages||0} 页</span>·
          <span>${Math.round(d.progress||0)}%</span>·
          <span>${d.source==='ocr'?'OCR':'文本层'}</span>
          ${d.confidence?`· <span>置信度 ${Math.round(d.confidence)}%</span>`:''}
          ${d.error?`· <span style="color:var(--danger)">${escapeHTML(d.error)}</span>`:''}
        </div>
      </div>
      ${d.status==='failed'?`<button class="btn btn-sm" data-retry="${d.id}">重试</button>`:''}
      ${d.status==='indexed'?`<button class="btn btn-sm primary" data-open="${d.id}">打开</button>`:''}
    </div>`).join('');
  $$('[data-retry]',wrap).forEach(b=> b.addEventListener('click', ()=>{
    const d = state.docs.find(x=>x.id===b.dataset.retry);
    if(d){ d.status='processing'; d.progress=0; d.error=null; idbPut('docs',d); processDoc(d); }
  }));
  $$('[data-open]',wrap).forEach(b=> b.addEventListener('click', ()=> openDoc(b.dataset.open)));
}
$('#btnRetryFailed').addEventListener('click', ()=>{
  const failed = state.docs.filter(d=>d.status==='failed');
  if(!failed.length){ toast('没有失败任务','info'); return; }
  failed.forEach(d=>{ d.status='processing'; d.progress=0; d.error=null; idbPut('docs',d); processDoc(d); });
  toast(`已重试 ${failed.length} 个任务`,'info');
});

// ---- Storage view ----
function computeStorage(){
  const filesBytes = state.docs.reduce((a,d)=> a+(d.size||0), 0);
  const ocrChars = state.pages.filter(p=>p.source==='ocr').reduce((a,p)=> a+(p.text?p.text.length:0), 0);
  const idxChars = state.pages.reduce((a,p)=> a+(p.words?p.words.length:0), 0);
  const citeBytes = JSON.stringify(state.citations).length;
  const ocrBytes = ocrChars*2; // utf-16 approx
  const idxBytes = idxChars*24;
  return { filesBytes, ocrBytes, idxBytes, citeBytes, total: filesBytes+ocrBytes+idxBytes+citeBytes };
}
function renderStorage(){
  const s = computeStorage();
  const total = Math.max(1, s.total);
  $('#heroStorage').textContent = fmtBytes(s.total);
  const segs = [
    {id:'segFiles', lg:'lgFiles', k:'files', v:s.filesBytes, label:'PDF 原文件'},
    {id:'segOcr', lg:'lgOcr', k:'ocr', v:s.ocrBytes, label:'OCR 文本'},
    {id:'segIndex', lg:'lgIndex', k:'index', v:s.idxBytes, label:'索引'},
    {id:'segCite', lg:'lgCite', k:'cite', v:s.citeBytes, label:'核验记录'},
  ];
  segs.forEach(sg=>{
    const el = $('#'+sg.id), lg = $('#'+sg.lg);
    const pct = (sg.v/total*100);
    el.style.width = pct+'%';
    el.dataset.value = String(sg.v);
    el.title = `${sg.label} ${fmtBytes(sg.v)} · ${pct.toFixed(1)}%`;
    lg.textContent = fmtBytes(sg.v);
    lg.dataset.value = String(sg.v);
  });
  $('#stDocs').textContent = state.docs.length;
  $('#stPages').textContent = state.pages.length;
  $('#stTokens').textContent = state.pages.reduce((a,p)=>a+(p.words?p.words.length:0),0).toLocaleString('zh-CN');
  $('#stCites').textContent = state.citations.length;
}
function updateStatusBar(){
  const s = computeStorage();
  $('#statusStorage').textContent = fmtBytes(s.total);
  $('#topStorageText').textContent = fmtBytes(s.total);
  // Assume 2GB soft quota for bar visualization
  const quota = 2*1024*1024*1024;
  $('#topStorageFill').style.width = Math.min(100, s.total/quota*100)+'%';
  $('#statusDocs').textContent = state.docs.length;
  $('#statusPages').textContent = state.pages.length;
  $('#statusTokens').textContent = state.pages.reduce((a,p)=>a+(p.words?p.words.length:0),0).toLocaleString('zh-CN');
  $('#navDocCount').textContent = state.docs.length;
  $('#navVerifyCount').textContent = state.citations.length;
}

$('#btnExportAll').addEventListener('click', ()=>{
  const payload = {
    version:1, exportedAt: new Date().toISOString(),
    docs: state.docs.map(({blob,thumb,...rest})=> rest),
    pages: state.pages, citations: state.citations,
  };
  const blob = new Blob([JSON.stringify(payload)],{type:'application/json'});
  downloadBlob(blob, `pdf-verify-export-${Date.now()}.json`);
  toast('已导出索引（不含 PDF 原文件）','success');
});
$('#btnImportIndex').addEventListener('click', ()=> $('#importInput').click());
$('#importInput').addEventListener('change', async e=>{
  const f = e.target.files[0]; if(!f) return;
  try{
    const text = await f.text();
    const data = JSON.parse(text);
    if(data.pages) for(const p of data.pages){ await idbPut('pages',p); if(!state.pages.find(x=>x.id===p.id)) state.pages.push(p); }
    if(data.citations) for(const c of data.citations){ await idbPut('citations',c); if(!state.citations.find(x=>x.id===c.id)) state.citations.push(c); }
    toast('索引导入成功','success');
    renderStorage(); renderVerify(); updateStatusBar();
  }catch(err){ toast('导入失败：'+err.message,'error'); }
  e.target.value='';
});
$('#btnClearAll').addEventListener('click', ()=> openModal());
function downloadBlob(blob, filename){
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href=url; a.download=filename; document.body.appendChild(a); a.click();
  setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); },200);
}

// ---- Modal ----
let modalAction = null;
function openModal(onConfirm){
  modalAction = onConfirm || (async ()=>{
    await idbClear('docs'); await idbClear('pages'); await idbClear('citations');
    state.docs=[]; state.pages=[]; state.citations=[]; state.currentDoc=null;
    state.currentResults=[]; state.currentQuery=''; $('#globalSearch').value='';
    renderLibrary(); renderSearch(); renderOCR(); renderStorage(); renderVerify(); updateStatusBar();
    switchView('library');
    toast('已清空全部本地数据','success');
  });
  $('#modalBackdrop').classList.add('open');
}
$('#modalCancel').addEventListener('click', ()=> $('#modalBackdrop').classList.remove('open'));
$('#modalBackdrop').addEventListener('click', e=>{ if(e.target.id==='modalBackdrop') $('#modalBackdrop').classList.remove('open'); });
$('#modalConfirm').addEventListener('click', async ()=>{
  $('#modalBackdrop').classList.remove('open');
  if(modalAction) await modalAction();
});

// ---- Sample PDF (via jsPDF) ----
async function loadSample(){
  if(!window.jspdf){ toast('示例生成需要 jsPDF（CDN 未加载）','warn'); return; }
  toast('正在生成示例 PDF…','info');
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({unit:'pt', format:'a4'});
  const W = doc.internal.pageSize.getWidth();
  const lines1 = [
    'Sample Contract for Local Verification',
    '',
    'Article 1  Purpose and Scope',
    'This Agreement is entered into on the 15th day of September, 2026,',
    'by and between Party A (the "Client") and Party B (the "Provider"),',
    'collectively referred to as the "Parties".',
    '',
    'Article 2  Payment Terms',
    'The Client shall pay the Provider the total fee of USD 120,000',
    'within thirty (30) days after the effective date of this Agreement.',
    'Late payment shall incur interest at 0.05% per day.',
    '',
    'Article 3  Confidentiality',
    'Both Parties agree to keep all non-public information confidential',
    'for a period of five (5) years from the date of disclosure.',
  ];
  doc.setFont('helvetica','bold'); doc.setFontSize(16);
  doc.text(lines1[0], 60, 70);
  doc.setFont('helvetica','normal'); doc.setFontSize(11);
  let y = 110;
  for(let i=1;i<lines1.length;i++){
    if(lines1[i].startsWith('Article')){ doc.setFont('helvetica','bold'); doc.setFontSize(12); }
    else { doc.setFont('helvetica','normal'); doc.setFontSize(11); }
    doc.text(lines1[i], 60, y); y += 20;
  }
  doc.addPage();
  doc.setFont('helvetica','bold'); doc.setFontSize(14);
  doc.text('Article 4  Term and Termination', 60, 70);
  doc.setFont('helvetica','normal'); doc.setFontSize(11);
  const lines2 = [
    'This Agreement shall commence on the effective date and continue',
    'for twelve (12) months unless terminated earlier by either Party',
    'with thirty (30) days written notice.',
    '',
    'Article 5  Governing Law',
    'This Agreement shall be governed by the laws of the place of',
    'signing. Any dispute shall be submitted to the competent court.',
    '',
    'Signed by:',
    '_________________________     _________________________',
    'Party A (Client)              Party B (Provider)',
  ];
  y = 100;
  for(const L of lines2){ doc.text(L, 60, y); y += 20; }

  const blob = doc.output('blob');
  blob.name = '示例合同-Sample-Contract.pdf';
  await handleFiles([blob]);
  // Also seed a demo citation
  setTimeout(()=>{
    if(!state.citations.length){
      const demo = {
        id: uid(), docId:'', docName:'示例合同-Sample-Contract.pdf', pageNo:1,
        original:'The Client shall pay the Provider the total fee of USD 120,000 within thirty (30) days after the effective date of this Agreement.',
        quote:'The Client shall pay the Provider the total fee of USD 120,000 within thirty days after the effective date of this Agreement.',
        verdict:'partial', sim:0.97, match:120, ins:0, del:4, createdAt: Date.now(),
      };
      idbPut('citations',demo); state.citations.push(demo); renderVerify(); updateStatusBar();
    }
  }, 6000);
}
$('#btnLoadSample').addEventListener('click', loadSample);
$('#btnEmptyLoad').addEventListener('click', loadSample);

// ---- Sort buttons ----
$('#btnSortRecent').addEventListener('click', ()=>{ state.docs.sort((a,b)=>b.addedAt-a.addedAt); renderLibrary(); });
$('#btnSortName').addEventListener('click', ()=>{ state.docs.sort((a,b)=>a.name.localeCompare(b.name,'zh-CN')); renderLibrary(); });

// ---- Boot ----
(async function boot(){
  try{
    db = await openDB();
    const [docs, pages, citations] = await Promise.all([idbAll('docs'), idbAll('pages'), idbAll('citations')]);
    state.docs = docs.sort((a,b)=>b.addedAt-a.addedAt);
    state.pages = pages;
    state.citations = citations;
    renderLibrary(); renderSearch(); renderOCR(); renderStorage(); renderVerify(); updateStatusBar();
    setEngineStatus('就绪 · '+state.ocrLang,'ok');
    if(!state.docs.length){
      setTimeout(()=> toast('提示：点击「载入示例」可零上传体验完整流程','info',4200), 600);
    }
  } catch(err){
    console.error(err);
    toast('IndexedDB 初始化失败：'+err.message,'error',5000);
  }
})();
